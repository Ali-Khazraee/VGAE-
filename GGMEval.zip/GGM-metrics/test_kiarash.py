# Generate graphs for demonstration purposes
import utils.graph_generators as gen
import pickle
import torch
import dgl
import tensorflow as tf
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
# sys_details = tf.sysconfig.get_build_info()
# cuda_version = sys_details["cuda_version"]
# print(cuda_version)
# set1 = gen.make_grid_graphs()
# set2 = gen.make_grid_graphs()
#----------------------------------
# OGB
# GRAN
# generated_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_ogbg-molbbbp_2022-Mar-03-19-38-31_449327/GRAN_molbbbp__gen_adj.npy"
# refrence_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_ogbg-molbbbp_2022-Mar-03-19-38-31_449327/GRAN_molbbbp__test_test_adj.npy"

# Gran 3000
# generated_dir = "Kernel_paper_Results/GRAN_molbbbp__gen_adj3000.npy"
# refrence_dir = "Kernel_paper_Results/GRAN_molbbbp__test_test_adj.npy"
# GraphRNN-MLP
# generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/graphs/crossEntropy_bestLR001_GraphRNN_MLP_grid_4_128_pred_3000_3.dat_nx22_"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/testGraphs_adj.npy"
# GraphRNN-RNN
# generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/GRIDRNN-rnn/crossEntropy_bestLR001_GraphRNN_RNN_grid_4_128_pred_3000_1.dat_nx22_"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/testGraphs_adj.npy"
# GraphRNN-RNN; second clone
# generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/GraphRNN_RNN_grid_4_128_pred_3000_1.dat_nx22_"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/testGraphs_adj.npy"

# kipf
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kipfBFSTrue200001647646910.3053346/Single_comp_generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kipfBFSTrue200001647646910.3053346/testGraphs_adj.npy"

# Graphrnn-rnn
# generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/crossEntropy_bestLR001_GraphRNN_RNN_ogbg-molbbbp_4_128_pred_3000_1.dat_nx22_"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kipfBFSTrue200001647646910.3053346/testGraphs_adj.npy"

# Graphrnn-MLP
# generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/OGB-RNN-MLP/crossEntropy_bestLR001_GraphRNN_MLP_ogbg-molbbbp_4_128_pred_3000_3.dat_nx22_"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kipfBFSTrue200001647646910.3053346/testGraphs_adj.npy"

#=====================================================================================================================
#graphRNN-s grid:
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/Single_comp_generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/testGraphs_adj.npy"

generated_dir = "/local-scratch/kiarash/google-research/bigg/data/grid-BFS/epoch-1000.ckpt.graphs-0Lobster_adj.npy"
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/testGraphs_adj.npy"

generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001650223264.7916732/Single_comp_generatedGraphs_adj.npy"
generated_dir = " /local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/BIGG/PTC_lattice_graph/generated.npy"
# grid
# grid kernel single
# #
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/Single_comp_generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/testGraphs_adj.npy"
# INFO:root:alpha: [1, 1, 1, 1, 1, 1, 1, 15000000, 3000000000]:
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647100805.05099/completeView/Single_comp_generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647100805.05099/completeView/testGraphs_adj.npy"

# INFO:root:alpha: alpha = [1, 1, 1, 1, 1, 1, 1, 20000000,  30000*100000]
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/Candidate_MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647466119.8876383/generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/Candidate_MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647466119.8876383/testGraphs_adj.npy"



# grid kipf single
#
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kipfBFSTrue200011646889047.9867027/completeView/Single_comp_generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kipfBFSTrue200011646889047.9867027/completeView/testGraphs_adj.npy"


#
# generated_dir = "Kernel_paper_Results/GRAN_grid__gen_adj.npy"
# refrence_dir = "Kernel_paper_Results/GRAN_grid__test_test_adj.npy"
# generated_dir = "Kernel_paper_Results/GRAN_grid__gen_adj3000.npy"
# refrence_dir = "Kernel_paper_Results/GRAN_grid__test_test_adj3000.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001647058261.395257/completeView/testGraphs_adj.npy"


#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
# lobster
# singlw con kernel
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200011646933663.9131842/completeView/Single_comp_generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200011646933663.9131842/completeView/testGraphs_adj.npy"

# all kernel
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200011646933663.9131842/completeView/generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200011646933663.9131842/completeView/testGraphs_adj.npy"

#all kipf
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kipfBFSTrue200011646884772.3415537/completeView/generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kipfBFSTrue200011646884772.3415537/completeView/testGraphs_adj.npy"

# # single kipf
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kipfBFSTrue200011646884772.3415537/completeView/Single_comp_generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_lobster_graphGeneration_kipfBFSTrue200011646884772.3415537/completeView/testGraphs_adj.npy"
# #
# # GRAN
# generated_dir = "Kernel_paper_Results/GRAN_lobster__gen_adj.npy"
# refrence_dir = "Kernel_paper_Results/GRAN_lobster__test_adj.npy"
# # GRAN
# generated_dir = "Kernel_paper_Results/GRAN_lobster__gen_adj3000.npy"
# refrence_dir = "Kernel_paper_Results/GRAN_lobster__test_test_adj3000.npy"

# graphrnn-rnn
# generated_dir = "Kernel_paper_Results/crossEntropy_bestLR001_GraphRNN_RNN_lobster_4_128_pred_3000_1.dat_nx22_"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/Lobster_adj_test.npy"
# graph rnn mlp
# generated_dir = "Kernel_paper_Results/crossEntropy_bestLR001_GraphRNN_MLP_lobster_4_128_pred_3000_3.dat_nx22_"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/Lobster_adj_test.npy"
#

# DD
#kipf
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_DD_graphGeneration_kipfBFSTrue200001647138192.79155/completeView/generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_DD_graphGeneration_kipfBFSTrue200001647138192.79155/completeView/testGraphs_adj.npy"

#kernel ??!!
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_DD_graphGeneration_kernelBFSTrue200001649702600.2528503/generatedGraphs_adj.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_DD_graphGeneration_kernelBFSTrue200001649702600.2528503/testGraphs_adj.npy"

# GRAN
# generated_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_DD_2022-Mar-04-17-42-36_40882/GRAN_DD__gen_adj3000.npy"
# refrence_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_DD_2022-Mar-04-17-42-36_40882/GRAN_DD__test_test_adj3000.npy"

#----------------------------
# # ugly script for checking 50/50 settng
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kernelBFSTrue200001647569490.511273/ogbg-molbbbp_dataset.npy"
# refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kernelBFSTrue200001647569490.511273/ogbg-molbbbp_dataset.npy"
#
# generated = np.load(generated_dir, allow_pickle=True)
# refrence = generated[:int(len(generated)/2)]
# generated = generated[int(len(generated)/2)+1:]


# kernel grid
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001650296200.4812605_candidate/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001650296200.4812605_candidate/Single_comp_generatedGraphs_adj_final_eval.npy"





# big- grid
refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/grid-BFS/test.npy"
generated_dir = "/local-scratch/kiarash/google-research/bigg/data/grid-BFS/generated.npy"


# OBG-BIGG
refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/ogbg-molbbbp/test.npy"
generated_dir= "/local-scratch/kiarash/google-research/bigg/data/ogbg-molbbbp/generated.npy"

# OGB kernel
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kernelBFSTrue200001650483214.3477259--CANDIDATE/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kernelBFSTrue200001650483214.3477259--CANDIDATE/Single_comp_generatedGraphs_adj_None.npy"
#----------------------------

# grid-kernel candidate
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001650422195.1629238Candidate/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_kernelBFSTrue200001650422195.1629238Candidate/Single_comp_generatedGraphs_adj_19998.npy"

# lobster kernel 1
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200001650241826.4672866Candidate3/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200001650241826.4672866Candidate3/Single_comp_generatedGraphs_adj_final_eval.npy"
# [0.0, 1.00001, 0.001440124388945206, 0.11080772502892274]



# lobster kernel 1
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200001650416293.789131Candidate/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_lobster_graphGeneration_kernelBFSTrue200001650416293.789131Candidate/Single_comp_generatedGraphs_adj_final_eval.npy"
# [0.007692305719941329, 0.9974458980933528, 0.0009707975860259426, 0.10461033650262679]


# lobster - bigg
refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/lobster_Kernel/test.npy"
generated_dir = "/local-scratch/kiarash/google-research/bigg/data/lobster_Kernel/epoch-1000.ckpt.graphs-0.npy"


#kipf  grid
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_grid_graphGeneration_kipfBFSTrue200001650570213.5868976/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_grid_graphGeneration_kipfBFSTrue200001650570213.5868976/Single_comp_generatedGraphs_adj_final_eval.npy"

#kipf  lobster
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_lobster_graphGeneration_kipfBFSTrue200001650594320.0680993/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_lobster_graphGeneration_kipfBFSTrue200001650594320.0680993/Single_comp_generatedGraphs_adj_final_eval.npy"


# DD graphrnn MLP
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Nips2022/MMD_AvePool_FC_DD_graphGeneration_kipfBFSTrue200001647138192.79155/completeView/testGraphs_adj.npy"
generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/DD-MLP/crossEntropy_bestLR001_GraphRNN_MLP_DD_4_128_pred_3000_3.dat_nx22_"

#kipf  OGB
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kipfBFSTrue200001650602661.635239/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kipfBFSTrue200001650602661.635239/Single_comp_generatedGraphs_adj_final_eval.npy"

# kernel OGB can 3

refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kernelBFSTrue200001650593090.9194453/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_kernelBFSTrue200001650593090.9194453/Single_comp_generatedGraphs_adj_final_eval.npy"

generated_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/GRAN_DD__gen_adj.npy"
refrence_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/GRAN_DD__test_test_adj.npy"

# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_DD_graphGeneration_kernelBFSTrue200001650675057.502729/Single_comp_generatedGraphs_adj_final_eval.npy"
# refrence_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/GRAN_DD__test_test_adj.npy"




#kernel-tri  lobster
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_Reported/MMD_AvePool_FC_lobster_graphGeneration_kipfBFSTrue200001650594320.0680993/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_lobster_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651348410.0159123/Single_comp_generatedGraphs_adj_final_eval.npy"


# kernel-tri
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651273589.400573/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651273589.400573/Single_comp_generatedGraphs_adj_final_eval.npy"


# kernel-tri good one
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651273589.400573/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_13998.npy"

# generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_18998.npy"
# generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_15998.npy"

# kernel-tri good one OGB
refrence_dir = "/local-scratch/kiarash/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651429096.0147955/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651429096.0147955/Single_comp_generatedGraphs_adj_final_eval.npy"

# grid kernel tri
refrence_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_13998.npy"
# [0.12783311167050565, 0.9266511438678433, 0.011839473208974114, 0.1265444004908204]

refrence_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_17998.npy"
# [0.06371546296279973, 0.9269054209339366, 0.00733852450760331, 0.175279588252306]

refrence_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_11998.npy"


# kernel-tri good one
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651273589.400573/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_13998.npy"
# [0.12783311167050565, 0.9266511438678433, 0.011839473208974114, 0.1265444004908204]

# generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_18998.npy"
# generated_dir = "/local-scratch/kiarash/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651363794.9637518/Single_comp_generatedGraphs_adj_15998.npy"


refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_lobster_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651529783.1296215/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_lobster_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651529783.1296215/Single_comp_generatedGraphs_adj_final_eval.npy"

#-----------------------------------------------------------------
# reproted result
# grid
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651552827.1952698/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651552827.1952698/Single_comp_generatedGraphs_adj_final_eval.npy"

#lobster
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_lobster_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651529783.1296215/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_lobster_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651529783.1296215/Single_comp_generatedGraphs_adj_final_eval.npy"

refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651544336.7176464/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651544336.7176464/Single_comp_generatedGraphs_adj_final_eval.npy"


# TRI - GRAN
refrence_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_triangular_grid_2022-May-08-15-01-34_348873/GRAN_triangular_grid__test_test_adj.npy"
generated_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_triangular_grid_2022-May-08-15-01-34_348873/GRAN_triangular_grid__gen_adj.npy"

# tri graphrnn -mlp
refrence_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_triangular_grid_2022-May-08-15-01-34_348873/GRAN_triangular_grid__test_test_adj.npy"
generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/tri-RNN/crossEntropy_bestLR001_GraphRNN_RNN_tri-grid_4_128_pred_3000_1.dat_nx22_"
# tri graphrnn -rnn
refrence_dir = "/local-scratch/kiarash/Baseline_GRAN/GRAN/exp/Reported/GRANMixtureBernoulli_triangular_grid_2022-May-08-15-01-34_348873/GRAN_triangular_grid__test_test_adj.npy"
generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/graphs/crossEntropy_bestLR001_GraphRNN_MLP_tri-grid_4_128_pred_3000_3.dat_nx22_"
# models.append([test_fname, pred_fname, None])

# DD kernek
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_DD_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651794595.150242/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_DD_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001651794595.150242/Single_comp_generatedGraphs_adj_final_eval.npy"

# DD kipf
refrence_dir =  "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_DD_graphGeneration_kipfBFSTrue200001647138192.79155/completeView/testGraphs_adj.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_DD_graphGeneration_kipfBFSTrue200001647138192.79155/completeView/Single_comp_generatedGraphs_adj.npy"

# tri kipf
refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_triangular_grid_graphGeneration_kipfBFSTrue200001651972897.5996404/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_triangular_grid_graphGeneration_kipfBFSTrue200001651972897.5996404/Single_comp_generatedGraphs_adj_final_eval.npy"

refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/tri/test.npy.npy"
generated_dir = "/local-scratch/kiarash/google-research/bigg/data/tri/generated.npy.npy"

refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/tri/test.npy"
generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/tri-MLP/crossEntropy_bestLR001_GraphRNN_MLP_tri-grid_4_128_pred_3000_3.dat_nx22_"

refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/tri/test.npy"
generated_dir = "/local-scratch/kiarash/GraphENN_remote_c/Reprted/tri-RNN/crossEntropy_bestLR001_GraphRNN_RNN_tri-grid_4_128_pred_3000_1.dat_nx22_"

refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_triangular_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001652199375.4136705/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/FinalResultHopefully/MMD_AvePool_FC_triangular_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001652199375.4136705/_triangular_grid_FC_KernelAugmentedWithTotalNumberOfTriangles_graphGeneration"

refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/DD/test.npy.npy"
generated_dir = "/local-scratch/kiarash/google-research/bigg/data/DD/epoch-1000.ckpt.graphs-0.npy"

generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/GRAN/GRAN_PTC_lattice_graph__gen_adj.npy"
#refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/BIGG/PTC_lattice_graph/test.npy"
refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/BIGG/PTC_lattice_graph/test.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/BIGG/PTC_lattice_graph/generated.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/re_MMD_AvePool_FC_PTC_graphGeneration_kipfBFSTrue/generatedGraphs_adj_final_eval.npy"
#refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_PTC_graphGeneration_kipfBFSTrue200001656384903.9104424/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_PTC_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001656384860.83536/generatedGraphs_adj_final_eval.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/MMD_AvePool_FC_PTC_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001656958224.2100985/generatedGraphs_adj_final_eval.npy"


generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/MMD_AvePool_FC_PTC_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001656958224.2100985/generatedGraphs_adj_final_eval.npy"
# refrence_dir = "/testGraphs_adj_.npy"
# generated_dir = "/Single_comp_generatedGraphs_adj_final_eval.npy"

#MUTAG
generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/generated.npy.npy" 
refrence_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/test.npy"




#PTC

#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/GRAN/GRAN_MUTAG_lattice_graph__gen_adj.npy"
#refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/test.npy"
#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/GRAPHRNN/crossEntropy_bestLR001_GraphRNN_MLP_MUTAG_4_128_pred_3000_1.dat_nx22_"
#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/GRAPHRNN/crossEntropy_bestLR001_GraphRNN_RNN_MUTAG_4_128_pred_3000_1.dat_nx22_"
#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_MUTAG_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001658096370.2089286/generatedGraphs_adj_final_eval.npy"
#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_MUTAG_graphGeneration_kipfBFSTrue200001658003428.4315262/generatedGraphs_adj_final_eval.npy"
generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/MMD_AvePool_FC_MUTAG_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001658172992.201439/generatedGraphs_adj_final_eval.npy"
refrence_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_MUTAG_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001658096370.2089286/testGraphs_adj_.npy"
#refrence_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651590362.4199145/testGraphs_adj_.npy"
#ref= "/local-scratch/kiarash/AAAI/QM9/Graph-Generative-Models/testGraphs_adj_.npy"


#generated_dir = "/local-scratch/kiarash/AAAI/QM9/Graph-Generative-Models/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659188393.12865/generatedGraphs_adj_final_eval.npy"
#refrence_dir= "/kiarash/AAAI/QM9/Graph-Generative-Models/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659188393.12865/testGraphs_adj_.npy"
#generated_dir= "/local-scratch/kiarash/AAAI/QM9/Graph-Generative-Models/MMD_AvePool_FC_QM9_graphGeneration_kipfBFSTrue120001659115131.1673634/generatedGraphs_adj_final_eval.npy"
#generated_dir="/local-scratch/kiarash/AAAI/QM9/Graph-Generative-Models/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659178699.3839335/generatedGraphs_adj_final_eval.npy"
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_ogbg-molbbbp_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001651590362.4199145/Single_comp_generatedGraphs_adj_final_eval.npy"

generated_dir="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_MUTAG_graphGeneration_kipfBFSTrue200001658003428.4315262/generatedGraphs_adj_final_eval.npy"
generated_dir="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_MUTAG_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001658096370.2089286/generatedGraphs_adj_final_eval.npy"
refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_MUTAG_graphGeneration_kipfBFSTrue200001658003428.4315262/testGraphs_adj_.npy"

refrence_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_PTC_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001656384860.83536/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_PTC_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001656384860.83536/generatedGraphs_adj_final_eval.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MMD_AvePool_FC_PTC_graphGeneration_kipfBFSTrue200001656384903.9104424/generatedGraphs_adj_final_eval.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/GRAN/GRAN_PTC_lattice_graph__gen_adj.npy"
refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/BIGG/PTC_lattice_graph/test.npy"
generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/GRAN/GRAN_PTC_lattice_graph__gen_adj.npy"
#generated_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/BIGG/PTC_lattice_graph/generated.npy"

generated_dir="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/GraphRNN/crossEntropy_bestLR001_GraphRNN_RNN_PTC_4_128_pred_300_1.dat_nx22_"
#generated_dir="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/PTC_result/GraphRNN/crossEntropy_bestLR001_GraphRNN_MLP_PTC_4_128_pred_3000_1.dat_nx22_"
#refrence_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/test.npy"
#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/GRAPHRNN/crossEntropy_bestLR001_GraphRNN_RNN_MUTAG_4_128_pred_3000_1.dat_nx22_"

#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/GRAN/GRAN_MUTAG_lattice_graph__gen_adj.npy"
#refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/test.npy"
#generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/GRAPHRNN/crossEntropy_bestLR001_GraphRNN_MLP_MUTAG_4_128_pred_3000_1.dat_nx22_"
generated_dir="/local-scratch/kiarash/GGM-metrics/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659178699.3839335/generatedGraphs_adj_final_eval.npy"
refrence_dir ="/local-scratch/kiarash/GGM-metrics/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659178699.3839335/testGraphs_adj_.npy"
generated_dir="/local-scratch/kiarash/AAAI/QM9/Graph-Generative-Models/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659178699.3839335/generatedGraphs_adj_final_eval.npy"
refrence_dir ="/local-scratch/kiarash/AAAI/QM9/Graph-Generative-Models/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659178699.3839335/testGraphs_adj_.npy"
generated_dir="/local-scratch/kiarash/AAAI/trans/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664459168.5584857/generatedGraphs_adj_final_eval.npy"
refrence_dir="/local-scratch/kiarash/AAAI/trans/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664459168.5584857/testGraphs_adj_.npy"


generated_dir= "/local-scratch/kiarash/AAAI/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664847971.941231/generatedGraphs_adj_final_eval.npy"

refrence_dir = "/local-scratch/kiarash/AAAI/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664847971.941231/testGraphs_adj_.npy"
#generated_dir= "MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664398073.3391838/generatedGraphs_adj_final_eval.npy"

#refrence_dir = "MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664398073.3391838/testGraphs_adj_.npy"

#generated_dir= "/local-scratch/kiarash/AAAI/trans/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664398073.3391838/generatedGraphs_adj_final_eval.npy"

#refrence_dir = "/local-scratch/kiarash/AAAI/trans/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue1001664398073.3391838/testGraphs_adj_.npy"



generated_dir= "/local-scratch/kiarash/AAAI/LDPVAE/MMD_AvePool_FC_MUTAG_graphGeneration_PMIBFSTrue400001673562280.380619/Val_Max_Con_comp_generatedGraphs_adj_39999.npy"

refrence_dir = "/local-scratch/kiarash/AAAI/LDPVAE/MMD_AvePool_FC_MUTAG_graphGeneration_PMIBFSTrue400001673562280.380619/Val__Target_Graphs_adj_39999.npy"

generated_dir= "/local-scratch/kiarash/AAAI/LDPVAE/MMD_AvePool_FC_MUTAG_graphGeneration_PMIBFSTrue400001673491077.2410905/Val_Max_Con_comp_generatedGraphs_adj_39999.npy"

refrence_dir = "/local-scratch/kiarash/AAAI/LDPVAE/MMD_AvePool_FC_MUTAG_graphGeneration_PMIBFSTrue400001673491077.2410905/Val__Target_Graphs_adj_39999.npy"


refrence_dir = "/local-scratch/kiarash/google-research/bigg/data/IMDBBINARY_lattice_graph/test.npy"
generated_dir = "/local-scratch/kiarash/google-research/bigg/data/IMDBBINARY_lattice_graph/generated.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Arxived_BaseLines/Graphrnn/GraphRNN_IMdB/crossEntropy_bestLR001_GraphRNN_RNN_IMDBBINARY_4_128_pred_3000_1.dat_nx22_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Arxived_BaseLines/Graphrnn/GraphRNN_IMdB/crossEntropy_bestLR001_GraphRNN_MLP_IMDBBINARY_4_128_pred_3000_3.dat_nx22_"
refrence_dir = "/local-scratch/kiarash/AAAI/Arxived_BaseLines/GGRAN/GRANMixtureBernoulli_IMDBBINARY_lattice_graph_2022-Jul-06-16-32-41_123409/GRAN_IMDBBINARY_lattice_graph__test_test_adj.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Arxived_BaseLines/GGRAN/GRANMixtureBernoulli_IMDBBINARY_lattice_graph_2022-Jul-06-16-32-41_123409/GRAN_IMDBBINARY_lattice_graph__gen_adj.npy"
#
refrence_dir = "/local-scratch/kiarash/AAAI/Arxived_BaseLines/GraphVAE-MM/MMD_AvePool_FC_IMDBBINARY_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001657660953.7991312/testGraphs_adj_.npy"
generated_dir = "/local-scratch/kiarash/AAAI/Arxived_BaseLines/GraphVAE-MM/MMD_AvePool_FC_IMDBBINARY_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue200001657660953.7991312/Single_comp_generatedGraphs_adj_19999.npy"
#
#generated_dir= "/local-scratch/kiarash/AAAI/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_kipfBFSTrue1001664285697.2182207/generatedGraphs_adj_final_eval.npy"
#generated_dir = "/local-scratch/kiarash/AAAI/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_kipfBFSTrue1001664285697.2182207/testGraphs_adj_.npy"
#refrence_dir = "/local-scratch/kiarash/AAAI/GraphVAE-MM/MMD_AvePool_FC_QM9_graphGeneration_kipfBFSTrue1001664285697.2182207/testGraphs_adj_.npy"
generated_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/generated.npy.npy"
refrence_dir ="/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/test.npy"
refrence_dir = "/local-scratch/kiarash/Nips2022/GraphVAE-MM/ReportedResult/MUTAG/BIG_MUTAG_lattice_graph/test.npy"
def selfLoop(graph_list):
    # graph_list = [graph.add_edges_from([(i,i) for i in graph.number_of_nodes]) for graph in graph_list]
    for graph in graph_list:
        graph.add_edges_from([(i,i) for i in range(graph.number_of_nodes())])
    return  graph_list

def load_graph_list(fname,remove_self=True):
    with open(fname, "rb") as f:
        glist = np.load(f, allow_pickle=True)
    graph_list =[]
    for G in glist:
        try:
            if type(G)==list:
                if len(G[0])==0:
                    continue
                graph = nx.Graph()
                graph.add_nodes_from(G[0])
                graph.add_edges_from(G[1])
            elif type(G)==nx.classes.graph.Graph:
                graph = G
            else:
                graph = nx.from_numpy_matrix(G)
            if remove_self:
                graph.remove_edges_from(nx.selfloop_edges(graph))
            graph.remove_nodes_from(list(nx.isolates(graph)))
            Gcc = sorted(nx.connected_components(graph), key=len, reverse=True)
            graph = graph.subgraph(Gcc[0])
            graph = nx.Graph(graph)
            graph_list.append(graph)
        except:
            print("cpould not read a graph")
    return graph_list

# generated = np.load(generated_dir, allow_pickle=True)
# refrence = np.load(refrence_dir, allow_pickle=True)
#/local-scratch/kiarash/AAAI/QM9/Graph-Generative-Models/MMD_AvePool_FC_QM9_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue120001659188393.12865/generatedGraphs_adj_final_eval.npy



# generated = [nx.from_numpy_matrix(g_) for g_ in generated]
# refrence = [nx.from_numpy_matrix(g_) for g_ in refrence]
refrence = load_graph_list(refrence_dir)
generated = load_graph_list(generated_dir)

#
# generated_dir = "/local-scratch/kiarash/AAAI/Graph-Generative-Models/MMD_AvePool_FC_triangular_grid_graphGeneration_KernelAugmentedWithTotalNumberOfTrianglesBFSTrue100001652050330.290702/triangular_grid_datasetkia.npy"
# loadedGraphs = load_graph_list(generated_dir)
#
# refrence = loadedGraphs[:int(len(loadedGraphs)/2)]
# generated = loadedGraphs[int(len(loadedGraphs)/2)+1:]

# for graph in generated:
#     pos = nx.spring_layout(graph, iterations=1000)
#     nx.draw(graph, pos, node_size=20, width=1, edge_color="black")
#     plt.show()

generated = generated[:len(refrence)]
generated = selfLoop(generated)
refrence = selfLoop(refrence)

device =  torch.device('cpu')

generated = [dgl.DGLGraph(g).to(device) for g in generated] # Convert graphs to DGL from NetworkX
refrence = [dgl.DGLGraph(g).to(device) for g in refrence] # Convert graphs to DGL from NetworkX
# Compute all GNN-based metrics at once
from evaluation.evaluator import Evaluator

f1 = []
mmd_rbf = []
for i in range(10):
    evaluator = Evaluator(device=device)
    result = evaluator.evaluate_all(generated, refrence)
    f1.append(result["f1_pr"])
    mmd_rbf.append(result["mmd_rbf"])


f1_std= np.array(f1).std()
f1_mean= np.array(f1).mean()

mmd_rbf_std= np.array(mmd_rbf).std()
mmd_rbf_mean= np.array(mmd_rbf).mean()
res = [f1_std, f1_mean, mmd_rbf_std, mmd_rbf_mean]

print(res)
